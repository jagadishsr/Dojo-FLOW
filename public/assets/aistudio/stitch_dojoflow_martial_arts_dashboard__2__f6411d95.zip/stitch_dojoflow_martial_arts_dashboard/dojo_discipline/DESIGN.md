---
name: Dojo Discipline
colors:
  surface: '#faf9ff'
  surface-dim: '#d8d9e4'
  surface-bright: '#faf9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fe'
  surface-container: '#ecedf8'
  surface-container-high: '#e6e7f3'
  surface-container-highest: '#e0e2ed'
  on-surface: '#181b23'
  on-surface-variant: '#5b403e'
  inverse-surface: '#2d3039'
  inverse-on-surface: '#eff0fb'
  outline: '#906f6d'
  outline-variant: '#e4bdba'
  surface-tint: '#bb1423'
  primary: '#a30018'
  on-primary: '#ffffff'
  primary-container: '#c9212b'
  on-primary-container: '#ffe0de'
  inverse-primary: '#ffb3ae'
  secondary: '#b02c32'
  on-secondary: '#ffffff'
  secondary-container: '#fe6666'
  on-secondary-container: '#69000f'
  tertiary: '#005574'
  on-tertiary: '#ffffff'
  tertiary-container: '#006f96'
  on-tertiary-container: '#cdebff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ae'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#930015'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b0'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#8e111e'
  tertiary-fixed: '#c3e8ff'
  tertiary-fixed-dim: '#82d0fb'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#faf9ff'
  on-background: '#181b23'
  surface-variant: '#e0e2ed'
  canvas-warm: '#F7F6F3'
  surface-card: '#FFFFFF'
  text-secondary: '#777D87'
  border-subtle: '#E6E6E8'
  status-success: '#1E9B61'
  status-warning: '#E9A52A'
  status-error: '#D94141'
typography:
  display-metric:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  section-title:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.06em
  org-title:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  card-title:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-badge:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

# DojoFLOW Studio — Design System & Authoritative Specification (Sprint 03)

## Authoritative Palette
- **Primary Red:** `#C9212B` (Header gradient right, primary action buttons, active dojo tab, raised punching emblem FAB)
- **Deep Red:** `#971923` (Header gradient left, active card accents, prominent badges)
- **Warm Background:** `#F7F6F3` (Master app canvas background, soft luxury martial arts aesthetic)
- **Card Background:** `#FFFFFF` (Card surfaces, clean white container)
- **Primary Text:** `#20232B` (Headings, primary values, high contrast typography)
- **Secondary Text:** `#777D87` (Labels, captions, timestamps, supporting notes)
- **Border:** `#E6E6E8` (Fine borders, dividers, subtle card boundaries)
- **Success:** `#1E9B61` (Paid status, present attendance, active indicators)
- **Warning:** `#E9A52A` (Pending dues, grading review alerts)
- **Error:** `#D94141` (Absent badges, overdue notices, validation alerts)

## Typography & Hierarchy (Inter / Manrope)
- **Organisation Title:** 13px bold uppercase tracking-wider
- **Page Headings:** 18px-20px semibold
- **Section Headings:** 14px-15px medium uppercase tracking-wide
- **Card Headings:** 14px-16px semibold/medium
- **Body & Supporting:** 12px-13px regular / medium
- **Metrics & Numbers:** 24px-28px bold prominent
- **Labels & Badges:** 10px-11px font-medium / semibold uppercase

## Global Standards
- **Header:** Full-width `#971923` to `#C9212B` gradient, organization crest, uppercase org title, "POWERED BY DOJOFLOW", right profile avatar and settings gear.
- **Dojo Selector:** Horizontally scrollable pill tabs: `SRI SANKARA DOJO (CHENNAI)` (active red), `BENGALURU DOJO`, `DELHI DOJO`. No "ALL DOJOS" button.
- **Bottom Navigation:** Fixed 5-tab bar: `STUDENTS`, `SCHEDULE`, central raised 62px circular red button with white karate punching emblem (`HOME`), `EVENTS`, `STATS`.
- **Localization:** Demonstration Organisation: *Japan Funakoshi Shotokan Karate India Federation (JFSKIF)*. Currency: `₹` (INR), Phone: `+91`, Time: 12-hour format with AM/PM, Timezone: IST (Asia/Kolkata).
- **Payment Modes:** UPI, Cash, Bank Transfer, Card, Other. No foreign gym terms (no mat kiosk, mat spot, tatami density).
