---
name: DojoFLOW Studio
colors:
  surface: '#f8f9ff'
  surface-dim: '#d5dae5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e9eef9'
  surface-container-high: '#e3e8f4'
  surface-container-highest: '#dde3ee'
  on-surface: '#161c24'
  on-surface-variant: '#5b403e'
  inverse-surface: '#2b3139'
  inverse-on-surface: '#ebf1fc'
  outline: '#906f6d'
  outline-variant: '#e4bdba'
  surface-tint: '#bb1423'
  primary: '#a30018'
  on-primary: '#ffffff'
  primary-container: '#c9212b'
  on-primary-container: '#ffe0de'
  inverse-primary: '#ffb3ae'
  secondary: '#b02c32'
  on-secondary: '#ffffff'
  secondary-container: '#fe6666'
  on-secondary-container: '#69000f'
  tertiary: '#4c4f58'
  on-tertiary: '#ffffff'
  tertiary-container: '#656771'
  on-tertiary-container: '#e5e6f2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ae'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#930015'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b0'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#8e111e'
  tertiary-fixed: '#e0e2ed'
  tertiary-fixed-dim: '#c4c6d1'
  on-tertiary-fixed: '#181b23'
  on-tertiary-fixed-variant: '#44474f'
  background: '#f8f9ff'
  on-background: '#161c24'
  surface-variant: '#dde3ee'
typography:
  display:
    fontFamily: Inter
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  metric-stat:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 2.5rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system delivers an operational interface tailored for martial arts academies, dojos, and modern combat fitness spaces. Combining the discipline and intentionality of martial practice with the structural efficiency of high-tier enterprise software, the visual atmosphere balances precision, respect, and functional agility.

The design movement anchors in **Corporate / Modern** execution with understated architectural minimalism:
- **Tone:** Authoritative, disciplined, refined, and frictionless.
- **Audience:** Academy owners, head instructors, front-desk administrators, and practitioners demanding quick check-ins, roster oversight, billing automation, and belt progression workflows.
- **Atmospheric Stance:** Interfaces avoid loud gamification or aggressive visual tropes. Instead, clarity and respect take precedence, utilizing warm paper-like ground surfaces, controlled crimson accent points, crisp outlines, and generous spatial discipline.

## Colors

The palette employs a restrained, intentional balance:
- **Primary Red (`#C9212B`):** Applied exclusively to focal interaction points, state affirmations, primary CTAs, active tab underlines, and critical martial rank indicators.
- **Deep Red (`#971923`):** Anchors hover states, key micro-gradients (`linear-gradient(135deg, #971923 0%, #C9212B 100%)`), and elevated metric callouts.
- **Base Neutral Tone (`#20232B`):** The primary ink for crisp typography, strong borders, and structural iconography.
- **Muted Neutral (`#777D87`):** Reserved for metadata, column headers, secondary action states, and subtle badges.
- **Warm Ground Canvas (`#F7F6F3`):** Replaces harsh sterile digital whites with a warm, tatami-neutral ground layer. Elevated cards, modals, and sheets rest atop this canvas in pure white (`#FFFFFF`).
- **Semantic Accents:** Success (`#1E9B61`) highlights belt advancement, cleared memberships, and valid payments; Warning (`#E9A52A`) tracks inventory thresholds and renewal expirations.

## Typography

Typography prioritizes utilitarian clarity, strict structural alignment, and clear optical weight steps:
- **Inter** handles all typographic roles across display headers, high-density roster grids, and analytical numeric readouts.
- **Letter Spacing:** Tighter kerning (`-0.02em` to `-0.01em`) is enforced on large displays and headers to maintain a compact, executive posture. Data tags and micro-labels carry slight positive tracking (`0.01em` to `0.04em`) to ensure legibility when rendered in all-caps or small dimensions.
- **Numeric Rhythm:** Numbers inside schedules, attendances, and financial rollouts use tabular alignment rules where applicable to support effortless vertical scanning.

## Layout & Spacing

The layout balances mobile expediency (for mat-side attendance tracking and check-in kiosks) with high-density multi-pane views on desktop administration stations:
- **Grid Architecture:** 
  - **Mobile (390px baseline):** Single column fluid canvas with `16px` outer margins and `12px` component gaps.
  - **Tablet (768px):** 8-column layout with `20px` gutters and `32px` outer margins.
  - **Desktop (1200px+):** 12-column grid anchored by a fixed `260px` operational sidebar, `24px` column gutters, and `40px` section margins.
- **Rhythm & Structure:** All spatial relationships derive from a 4px/8px incremental base. Large data cards leverage `space-lg` (`24px`) internal padding to sustain a light, breathable feel, while compact toolbars and data strips condense into `space-sm` (`12px`) and `space-xs` (`8px`).

## Elevation & Depth

Visual hierarchy uses a layered strategy of subtle, warm-tinted drops combined with ultra-fine hairpins:
- **Surface Strategy:** The lowest canvas layer is `#F7F6F3`. Operational modules sit on pristine `#FFFFFF` surfaces. Nested list rows or interactive table segments transition to `#F7F6F3` on hover.
- **Ambient Elevation:**
  - **Resting Cards:** `box-shadow: 0 2px 10px rgba(0, 0, 0, 0.04), 0 1px 3px rgba(0, 0, 0, 0.02);` accompanied by a hairline border: `1px solid rgba(32, 35, 43, 0.08)`.
  - **Active / Hover State:** `box-shadow: 0 8px 24px rgba(32, 35, 43, 0.06), 0 2px 6px rgba(32, 35, 43, 0.03);` with an element shift of `-1px`.
  - **Overlays / Flyout Drawers:** `box-shadow: 0 16px 40px rgba(0, 0, 0, 0.08);` with a muted matte backdrop `rgba(32, 35, 43, 0.35)`.
- **Borders:** Low-contrast ghost lines (`rgba(32, 35, 43, 0.08)`) define edges without adding visual noise, keeping the focus squarely on student data, attendance rates, and active schedules.

## Shapes

The geometry reflects roundedness level **2**, striking a balanced harmony between architectural rigidity and modern accessibility:
- **Core Elements:** Standard inputs, buttons, chips, and small cards use `0.5rem` to `0.75rem` (8px to 12px) corners.
- **Large Panels & Modals:** Primary dashboard containers, dialog sheets, and calendar blocks apply `1rem` (16px) corners (`rounded-lg`).
- **Pills & Status Indicators:** Belt advancement tokens, small pill badges, and avatar frames use full radii (`rounded-full` / 9999px) to contrast with the surrounding geometric panels.

## Components

### Buttons
- **Primary:** Gradient fill `linear-gradient(135deg, #971923 0%, #C9212B 100%)`, white typography (`Inter` Medium 14px), 12px border radius, 0 1px 2px rgba(0, 0, 0, 0.05). Hover subtly brightens overlay; active state compresses to scale `0.99`.
- **Secondary / Neutral:** Crisp white background, 1px border `rgba(32, 35, 43, 0.12)`, text `#20232B`. Hover state applies `#F7F6F3` fill.
- **Destructive:** Soft crimson background tinted at 10% opacity, `#C9212B` text, 0px shadow.

### Inputs & Select Fields
- Height: 42px on desktop, 46px on mobile viewports for effortless finger-tap accuracy.
- Base style: Pure white surface, 1px border `rgba(32, 35, 43, 0.14)`, 10px corner radius, text `#20232B`.
- Focus state: Border shifts to `#C9212B` with a companion ring: `0 0 0 3px rgba(201, 33, 43, 0.12)`.
- Placeholder: `#777D87` in regular 14px.

### Cards & Metrics
- Pure white fill, 12px to 16px corner radius, standard 1px border `rgba(32, 35, 43, 0.08)`, and resting ambient shadow.
- Metric cards display label in 11px uppercase (`#777D87`, tracking `0.04em`), dynamic bold statistic in 28px (`#20232B`), and micro-trend pills in green/amber with soft tinted pill backdrops.

### Chips & Badges
- Height: 24px. Radius: Full pill (9999px).
- Belt Rank Chips: Tailored pill with a crisp 1px border matching the respective discipline rank (e.g., White, Blue, Purple, Brown, Black) with clear micro-typography.
- Status Chips: Active (`#1E9B61` text on `rgba(30, 155, 97, 0.1)`), At-Risk (`#E9A52A` text on `rgba(233, 165, 42, 0.1)`).

### Selection Controls (Checkboxes & Radios)
- Checkboxes: 18x18px square with 4px border radius. Border `rgba(32, 35, 43, 0.25)`. Checked state produces primary red fill with white centered check mark.
- Radio buttons: 18x18px circle, checked state introduces a solid primary `#C9212B` inner circle with 3px white cushion.

### Data Rosters & Lists
- Row heights configured at 56px to ensure rapid scanning on mobile and desk stations.
- Alternating subtle hovers (`#F7F6F3`), separated by 1px bottom border `rgba(32, 35, 43, 0.05)`.
- Right-aligned actions feature quick-action contextual buttons that reveal on hover or persist in mobile views.